package hr.fer.zemris.java.hw03.prob1;

/**
 * State of the <code>Lexer</code> used to determine the way of parsing.
 * @author Dorian Ivankovic
 *
 */
public enum LexerState {
	BASIC, EXTENDED;
}
