package hr.fer.zemris.java.custom.collections.demo;


/**
 * Contains basic operations that can be executed using a stack and postfix notation.
 * Postfix notation : <a href="https://en.wikipedia.org/wiki/Reverse_Polish_notation">https://en.wikipedia.org/wiki/Reverse_Polish_notation</a>.
 * @author Dorian Ivankovic
 *
 */
public enum StackOperation {
	ADD("+"),
	SUB("-"),
	DIV("/"),
	MUL("*"),
	MOD("%");
	
	private String value;
	
	private StackOperation(String value) {
		this.value = value;
	}
	
	/**
	 * Return the string representation of the operation.
	 * @return operation
	 */
	public String getValue() {
		return value;
	}
		
}
