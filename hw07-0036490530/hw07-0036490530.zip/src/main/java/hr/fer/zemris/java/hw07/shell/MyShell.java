package hr.fer.zemris.java.hw07.shell;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Collections;
import java.util.SortedMap;
import java.util.TreeMap;

import hr.fer.zemris.java.hw07.shell.commands.CatCommand;
import hr.fer.zemris.java.hw07.shell.commands.CharsetsCommand;
import hr.fer.zemris.java.hw07.shell.commands.CopyCommand;
import hr.fer.zemris.java.hw07.shell.commands.ExitCommand;
import hr.fer.zemris.java.hw07.shell.commands.HelpCommand;
import hr.fer.zemris.java.hw07.shell.commands.HexdumpCommand;
import hr.fer.zemris.java.hw07.shell.commands.LsCommand;
import hr.fer.zemris.java.hw07.shell.commands.MkdirCommand;
import hr.fer.zemris.java.hw07.shell.commands.ShellCommand;
import hr.fer.zemris.java.hw07.shell.commands.SymbolCommand;
import hr.fer.zemris.java.hw07.shell.commands.TreeCommand;

/**
 * Simple shell program, supports basic shell operations - help, symbol, exit,
 * mkdir, cat, ls, tree, ... <br>
 * To find out more about supported operations use command help. <br>
 * To write multi line commands, write more lines symbol at the end of the line.
 * <br>
 * Special symbols can be found out by using command symbol. <br>
 * For more information about shells see
 * <a href="https://en.wikipedia.org/wiki/Shell_(computing)">Shell</a>.
 * 
 * @author Dorian Ivankovic
 *
 */
public class MyShell {

	/**
	 * Shell environment, a concrete implementation of {@link Environment}.
	 * 
	 * @author Dorian Ivankovic
	 *
	 */
	private static class ShellEnvironment implements Environment {

		/**
		 * Map of supported commands.
		 */
		private SortedMap<String, ShellCommand> commands;

		/**
		 * Current prompt symbol.
		 */
		private char PROMPTSYMBOL = '>';

		/**
		 * Current morelines symbol.
		 */
		private char MORELINESSYMBOL = '\\';

		/**
		 * Current multilines symbol.
		 */
		private char MULTILINESYMBOL = '|';

		/**
		 * Reader used for reading user's inputs.
		 */
		private BufferedReader reader;

		/**
		 * Writer used for writing appropriate messages to the user.
		 */
		private BufferedWriter writer;

		/**
		 * Constructs a new <code>ShellEnvironment</code> using the input and output
		 * stream that will be used for reading and writing data to the user.
		 * 
		 * @param is
		 *            - input stream used for reading commands from the user
		 * @param os
		 *            - output stream used for writing data to the user
		 */
		public ShellEnvironment(InputStream is, OutputStream os) {
			reader = new BufferedReader(new InputStreamReader(new BufferedInputStream(is)));
			writer = new BufferedWriter(new OutputStreamWriter(new BufferedOutputStream(os)));

			commands = new TreeMap<String, ShellCommand>();

			commands.put("help", new HelpCommand());
			commands.put("exit", new ExitCommand());
			commands.put("symbol", new SymbolCommand());
			commands.put("cat", new CatCommand());
			commands.put("charsets", new CharsetsCommand());
			commands.put("copy", new CopyCommand());
			commands.put("hexdump", new HexdumpCommand());
			commands.put("ls", new LsCommand());
			commands.put("mkdir", new MkdirCommand());
			commands.put("tree", new TreeCommand());

		}

		@Override
		public String readLine() throws ShellIOException {

			try {
				String line = reader.readLine();
				return line;
			} catch (IOException e) {
				throw new ShellIOException();
			}

		}

		@Override
		public void write(String text) throws ShellIOException {

			try {
				writer.write(text);
				writer.flush();
			} catch (IOException e) {
				throw new ShellIOException();
			}

		}

		@Override
		public void writeln(String text) throws ShellIOException {

			try {
				writer.write(text);
				writer.newLine();
				writer.flush();
			} catch (IOException e) {
				throw new ShellIOException();
			}

		}

		@Override
		public SortedMap<String, ShellCommand> commands() {
			return Collections.unmodifiableSortedMap(commands);
		}

		@Override
		public Character getMultilineSymbol() {
			return MULTILINESYMBOL;
		}

		@Override
		public void setMultilineSymbol(Character symbol) {
			MULTILINESYMBOL = symbol;
		}

		@Override
		public Character getPromptSymbol() {
			return PROMPTSYMBOL;
		}

		@Override
		public void setPromptSymbol(Character symbol) {
			PROMPTSYMBOL = symbol;
		}

		@Override
		public Character getMorelinesSymbol() {
			return MORELINESSYMBOL;
		}

		@Override
		public void setMorelinesSymbol(Character symbol) {
			MORELINESSYMBOL = symbol;
		}

		/**
		 * Tries to close the input and output streams once called.
		 */
		public void terminate() {
			try {
				reader.close();
				writer.close();
			} catch (IOException ignorable) {
			}
		}

	}

	/**
	 * This method is called once the program is run.
	 * 
	 * @param args
	 *            - command line arguments
	 */
	public static void main(String[] args) {

		ShellEnvironment environment = new ShellEnvironment(System.in, System.out);
		
		try {
			environment.writeln("Welcome to MyShell v 1.0");

			ShellStatus status = ShellStatus.CONTINUE;
			do {
				environment.write(environment.getPromptSymbol() + " ");

				String line = environment.readLine();
				if (line.isEmpty()) continue;

				StringBuilder commandBuilder = new StringBuilder();

				if (line.endsWith(environment.getMorelinesSymbol().toString())) {

					commandBuilder.append(line.substring(0, line.lastIndexOf(environment.getMorelinesSymbol())));

					while (true) {
						environment.write(environment.getMultilineSymbol() + " ");
						line = environment.readLine();

						if (line.endsWith(environment.getMorelinesSymbol().toString())) {
							commandBuilder.append(line.substring(0, line.lastIndexOf(environment.getMorelinesSymbol())));
						} else {
							commandBuilder.append(line);
							break;
						}
					}

				} else {
					commandBuilder.append(line);
				}

				String commandArgs = commandBuilder.toString().trim();
				if (commandArgs.isEmpty()) continue;

				ShellCommand command = environment.commands().get(commandArgs.split("\\s+")[0]);
				if (command == null) {
					environment.writeln("Command doesnt exist. Use help to see available commands.");
					status = ShellStatus.CONTINUE;
				} else {
					status = command.executeCommand(environment, commandArgs.replaceFirst(command.getCommandName(), ""));
				}

			} while (status != ShellStatus.TERMINATE);

		} catch (ShellIOException ex) {
		} finally {
			environment.terminate();
		}
	}

}
