package hr.fer.zemris.java.custom.scripting.elems;

/**
 * Represents a constant element - elements with a numeric
 * value or a string element.
 * @author Dorian Ivankovic
 *
 */
public abstract class ElementConstant extends Element{

}
